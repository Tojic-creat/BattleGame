#pragma once

#include <cstddef>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace battle_game {

class Unit {
public:
    Unit(std::string id, std::string name, int cost, int maxHealth,
         int meleeDamage, int rangedDamage);
    virtual ~Unit() = default;

    Unit(const Unit&) = default;
    Unit& operator=(const Unit&) = default;

    virtual std::unique_ptr<Unit> clone() const = 0;

    const std::string& id() const noexcept { return id_; }
    const std::string& name() const noexcept { return name_; }
    int cost() const noexcept { return cost_; }
    int maxHealth() const noexcept { return maxHealth_; }
    int health() const noexcept { return health_; }
    int meleeDamage() const noexcept { return meleeDamage_; }
    int rangedDamage() const noexcept { return rangedDamage_; }
    bool isRanged() const noexcept { return rangedDamage_ > 0; }
    bool isAlive() const noexcept { return health_ > 0; }

    void takeDamage(int damage) noexcept;
    void setHealth(int health);

private:
    std::string id_;
    std::string name_;
    int cost_;
    int maxHealth_;
    int health_;
    int meleeDamage_;
    int rangedDamage_;
};

class LightUnit final : public Unit {
public:
    LightUnit();
    std::unique_ptr<Unit> clone() const override;
};

class HeavyUnit final : public Unit {
public:
    HeavyUnit();
    std::unique_ptr<Unit> clone() const override;
};

class RangedUnit final : public Unit {
public:
    RangedUnit();
    std::unique_ptr<Unit> clone() const override;
};

// Singleton: one shared catalog of unit prototypes.
class MilitaryAcademy {
public:
    static MilitaryAcademy& instance();

    MilitaryAcademy(const MilitaryAcademy&) = delete;
    MilitaryAcademy& operator=(const MilitaryAcademy&) = delete;

    void registerPrototype(std::unique_ptr<Unit> prototype);
    std::unique_ptr<Unit> createUnit(const std::string& id) const;
    std::vector<const Unit*> allTemplates() const;
    const Unit* findTemplate(const std::string& id) const noexcept;

private:
    MilitaryAcademy();

    std::unordered_map<std::string, std::unique_ptr<Unit>> prototypes_;
    std::vector<std::string> registrationOrder_;
};

class Army {
public:
    Army(std::string name, int budget);
    Army(Army&&) noexcept = default;
    Army& operator=(Army&&) noexcept = default;
    Army(const Army&) = delete;
    Army& operator=(const Army&) = delete;

    const std::string& name() const noexcept { return name_; }
    int initialBudget() const noexcept { return initialBudget_; }
    int remainingBudget() const noexcept { return remainingBudget_; }
    std::size_t totalUnits() const noexcept { return units_.size(); }
    std::size_t aliveCount() const noexcept;
    bool hasAliveUnits() const noexcept;

    std::vector<std::unique_ptr<Unit>>& units() noexcept { return units_; }
    const std::vector<std::unique_ptr<Unit>>& units() const noexcept { return units_; }
    Unit* frontUnit() noexcept;
    const Unit* frontUnit() const noexcept;

    bool addUnit(std::unique_ptr<Unit> unit);
    void addLoadedUnit(std::unique_ptr<Unit> unit);
    std::size_t removeDeadUnits();
    void setRemainingBudget(int budget);

private:
    std::string name_;
    int initialBudget_;
    int remainingBudget_;
    std::vector<std::unique_ptr<Unit>> units_;
};

// Base factory exposes factory methods for an army and an individual unit.
// The academy remains independent of these factories and is shared via Singleton.
class ArmyFactory {
public:
    virtual ~ArmyFactory() = default;
    virtual std::unique_ptr<Army> createArmy(const std::string& name, int budget) = 0;

    std::unique_ptr<Unit> createUnit(const std::string& typeId) const;
    MilitaryAcademy& createAcademy() const;
};

class GreedyArmyFactory final : public ArmyFactory {
public:
    std::unique_ptr<Army> createArmy(const std::string& name, int budget) override;
};

class RandomArmyFactory final : public ArmyFactory {
public:
    RandomArmyFactory();
    ~RandomArmyFactory() override;
    std::unique_ptr<Army> createArmy(const std::string& name, int budget) override;

private:
    class RandomState;
    std::unique_ptr<RandomState> random_;
};

enum class BattlePhase {
    Ranged = 0,
    MeleeX = 1,
    MeleeY = 2,
    Cleanup = 3,
    Finished = 4
};

struct StepResult {
    std::string message;
    bool roundEnded = false;
    bool finished = false;
};

class Battle {
public:
    Battle(Army armyX, Army armyY);
    Battle(Army armyX, Army armyY, int round, BattlePhase phase,
           std::size_t rangedCursorX, std::size_t rangedCursorY,
           int nextRangedArmy, int maxRounds = 5000);

    StepResult step();
    bool isFinished() const noexcept { return phase_ == BattlePhase::Finished; }
    std::string resultText() const;
    void printState() const;

    const Army& armyX() const noexcept { return armyX_; }
    const Army& armyY() const noexcept { return armyY_; }
    int round() const noexcept { return round_; }
    BattlePhase phase() const noexcept { return phase_; }
    std::size_t rangedCursorX() const noexcept { return rangedCursorX_; }
    std::size_t rangedCursorY() const noexcept { return rangedCursorY_; }
    int nextRangedArmy() const noexcept { return nextRangedArmy_; }
    int maxRounds() const noexcept { return maxRounds_; }

private:
    bool hasUnusedRangedUnit(const Army& army, std::size_t cursor) const;
    bool performRangedAttack(bool fromX, std::string& message);
    bool performMeleeAttack(bool fromX, std::string& message);
    bool checkFinished(std::string& message);
    static std::string phaseName(BattlePhase phase);

    Army armyX_;
    Army armyY_;
    int round_ = 1;
    BattlePhase phase_ = BattlePhase::Ranged;
    std::size_t rangedCursorX_ = 0;
    std::size_t rangedCursorY_ = 0;
    int nextRangedArmy_ = 0;
    int maxRounds_ = 5000;
};

class SaveManager {
public:
    static bool save(const Battle& battle, const std::string& path, std::string& error);
    static std::unique_ptr<Battle> load(const std::string& path, std::string& error);
};

} // namespace battle_game
