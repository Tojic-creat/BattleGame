@echo off
setlocal
where cl >nul 2>nul
if errorlevel 1 (
  echo ERROR: cl.exe was not found.
  echo Run this file from "x64 Native Tools Command Prompt for VS 2022"
  echo or open BattleGame.sln in Visual Studio and build the solution.
  pause
  exit /b 1
)
cl /nologo /std:c++17 /EHsc /W4 /utf-8 main.cpp src\BattleGame.cpp /Fe:BattleGame.exe
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Build successful: BattleGame.exe
pause
