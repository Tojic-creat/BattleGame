#include "BattleGame.hpp"

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <sstream>
#include <stdexcept>
#include <utility>

namespace battle_game {

Unit::Unit(std::string id, std::string name, int cost, int maxHealth,
           int meleeDamage, int rangedDamage)
    : id_(std::move(id)), name_(std::move(name)), cost_(cost),
      maxHealth_(maxHealth), health_(maxHealth),
      meleeDamage_(meleeDamage), rangedDamage_(rangedDamage) {
    if (id_.empty() || name_.empty()) throw std::invalid_argument("ID и имя юнита не должны быть пустыми.");
    if (cost_ <= 0 || maxHealth_ <= 0 || meleeDamage_ < 0 || rangedDamage_ < 0)
        throw std::invalid_argument("Некорректные характеристики юнита.");
}

void Unit::takeDamage(int damage) noexcept {
    if (damage > 0 && health_ > 0) health_ = std::max(0, health_ - damage);
}

void Unit::setHealth(int health) {
    if (health < 0 || health > maxHealth_) throw std::invalid_argument("Здоровье вне допустимого диапазона.");
    health_ = health;
}

LightUnit::LightUnit() : Unit("light", "Лёгкий", 20, 50, 30, 0) {}
std::unique_ptr<Unit> LightUnit::clone() const { return std::make_unique<LightUnit>(*this); }

HeavyUnit::HeavyUnit() : Unit("heavy", "Тяжёлый", 35, 150, 15, 0) {}
std::unique_ptr<Unit> HeavyUnit::clone() const { return std::make_unique<HeavyUnit>(*this); }

RangedUnit::RangedUnit() : Unit("ranged", "Лучник", 30, 40, 5, 20) {}
std::unique_ptr<Unit> RangedUnit::clone() const { return std::make_unique<RangedUnit>(*this); }

MilitaryAcademy& MilitaryAcademy::instance() {
    static MilitaryAcademy academy;
    return academy;
}

MilitaryAcademy::MilitaryAcademy() {
    registerPrototype(std::make_unique<LightUnit>());
    registerPrototype(std::make_unique<HeavyUnit>());
    registerPrototype(std::make_unique<RangedUnit>());
}

void MilitaryAcademy::registerPrototype(std::unique_ptr<Unit> prototype) {
    if (!prototype) throw std::invalid_argument("Нельзя зарегистрировать пустой шаблон юнита.");
    const std::string id = prototype->id();
    if (prototypes_.find(id) != prototypes_.end())
        throw std::invalid_argument("Шаблон с ID '" + id + "' уже зарегистрирован.");
    prototype->setHealth(prototype->maxHealth());
    registrationOrder_.push_back(id);
    prototypes_.emplace(id, std::move(prototype));
}

std::unique_ptr<Unit> MilitaryAcademy::createUnit(const std::string& id) const {
    const auto it = prototypes_.find(id);
    if (it == prototypes_.end()) throw std::invalid_argument("Неизвестный тип юнита: " + id);
    auto unit = it->second->clone();
    unit->setHealth(unit->maxHealth());
    return unit;
}

std::vector<const Unit*> MilitaryAcademy::allTemplates() const {
    std::vector<const Unit*> result;
    result.reserve(registrationOrder_.size());
    for (const auto& id : registrationOrder_) result.push_back(prototypes_.at(id).get());
    return result;
}

const Unit* MilitaryAcademy::findTemplate(const std::string& id) const noexcept {
    const auto it = prototypes_.find(id);
    return it == prototypes_.end() ? nullptr : it->second.get();
}

Army::Army(std::string name, int budget)
    : name_(std::move(name)), initialBudget_(budget), remainingBudget_(budget) {
    if (name_.empty()) name_ = "Армия";
    if (budget < 0) throw std::invalid_argument("Бюджет не может быть отрицательным.");
}

std::size_t Army::aliveCount() const noexcept {
    return static_cast<std::size_t>(std::count_if(units_.begin(), units_.end(),
        [](const auto& unit) { return unit && unit->isAlive(); }));
}

bool Army::hasAliveUnits() const noexcept { return aliveCount() > 0; }

Unit* Army::frontUnit() noexcept {
    for (auto& unit : units_) if (unit && unit->isAlive()) return unit.get();
    return nullptr;
}

const Unit* Army::frontUnit() const noexcept {
    for (const auto& unit : units_) if (unit && unit->isAlive()) return unit.get();
    return nullptr;
}

bool Army::addUnit(std::unique_ptr<Unit> unit) {
    if (!unit || unit->cost() > remainingBudget_) return false;
    remainingBudget_ -= unit->cost();
    units_.push_back(std::move(unit));
    return true;
}

void Army::addLoadedUnit(std::unique_ptr<Unit> unit) {
    if (!unit) throw std::invalid_argument("Повреждён файл сохранения: пустой юнит.");
    units_.push_back(std::move(unit));
}

std::size_t Army::removeDeadUnits() {
    const auto oldSize = units_.size();
    units_.erase(std::remove_if(units_.begin(), units_.end(),
        [](const auto& unit) { return !unit || !unit->isAlive(); }), units_.end());
    return oldSize - units_.size();
}

void Army::setRemainingBudget(int budget) {
    if (budget < 0 || budget > initialBudget_) throw std::invalid_argument("Некорректный остаток бюджета.");
    remainingBudget_ = budget;
}

std::unique_ptr<Unit> ArmyFactory::createUnit(const std::string& typeId) const {
    return createAcademy().createUnit(typeId);
}

MilitaryAcademy& ArmyFactory::createAcademy() const { return MilitaryAcademy::instance(); }

std::unique_ptr<Army> GreedyArmyFactory::createArmy(const std::string& name, int budget) {
    if (budget < 0) throw std::invalid_argument("Бюджет не может быть отрицательным.");
    auto army = std::make_unique<Army>(name, budget);
    auto templates = createAcademy().allTemplates();

    while (true) {
        const Unit* best = nullptr;
        double bestScore = -1.0;
        for (const Unit* candidate : templates) {
            if (candidate->cost() > army->remainingBudget()) continue;
            // Жадный критерий: боевая ценность на одну денежную единицу.
            const double value = candidate->maxHealth() * 0.5
                               + candidate->meleeDamage() * 2.0
                               + candidate->rangedDamage() * 2.5;
            const double score = value / candidate->cost();
            if (score > bestScore) {
                bestScore = score;
                best = candidate;
            }
        }
        if (!best) break;
        if (!army->addUnit(createUnit(best->id()))) break;
    }
    return army;
}

class RandomArmyFactory::RandomState {
public:
    std::mt19937 engine{std::random_device{}()};
};

RandomArmyFactory::RandomArmyFactory() : random_(std::make_unique<RandomState>()) {}
RandomArmyFactory::~RandomArmyFactory() = default;

std::unique_ptr<Army> RandomArmyFactory::createArmy(const std::string& name, int budget) {
    if (budget < 0) throw std::invalid_argument("Бюджет не может быть отрицательным.");
    auto army = std::make_unique<Army>(name, budget);
    auto templates = createAcademy().allTemplates();

    while (true) {
        std::vector<const Unit*> affordable;
        for (const Unit* candidate : templates)
            if (candidate->cost() <= army->remainingBudget()) affordable.push_back(candidate);
        if (affordable.empty()) break;
        std::uniform_int_distribution<std::size_t> pick(0, affordable.size() - 1);
        const Unit* chosen = affordable[pick(random_->engine)];
        if (!army->addUnit(createUnit(chosen->id()))) break;
    }
    return army;
}

Battle::Battle(Army armyX, Army armyY, int firstArmy)
    : armyX_(std::move(armyX)), armyY_(std::move(armyY)),
      phase_(firstArmy == 0 ? BattlePhase::MeleeX : BattlePhase::MeleeY),
      nextRangedArmy_(firstArmy), firstArmy_(firstArmy) {
    if (firstArmy_ < 0 || firstArmy_ > 1)
        throw std::invalid_argument("Первой атакующей армией должна быть X (0) или Y (1).");
    std::string ignored;
    checkFinished(ignored);
}

Battle::Battle(Army armyX, Army armyY, int round, BattlePhase phase,
               std::size_t rangedCursorX, std::size_t rangedCursorY,
               int nextRangedArmy, int firstArmy, int maxRounds)
    : armyX_(std::move(armyX)), armyY_(std::move(armyY)), round_(round), phase_(phase),
      rangedCursorX_(rangedCursorX), rangedCursorY_(rangedCursorY),
      nextRangedArmy_(nextRangedArmy), firstArmy_(firstArmy), maxRounds_(maxRounds) {
    if (round_ < 1 || nextRangedArmy_ < 0 || nextRangedArmy_ > 1 ||
        firstArmy_ < 0 || firstArmy_ > 1 || maxRounds_ < 1)
        throw std::invalid_argument("Некорректное состояние боя в сохранении.");
    if (static_cast<int>(phase_) < 0 || static_cast<int>(phase_) > static_cast<int>(BattlePhase::Finished))
        throw std::invalid_argument("Неизвестный этап боя в сохранении.");
    std::string ignored;
    checkFinished(ignored);
}

bool Battle::hasUnusedRangedUnit(const Army& army, std::size_t cursor) const {
    const auto& units = army.units();
    for (std::size_t i = cursor; i < units.size(); ++i)
        if (units[i] && units[i]->isAlive() && units[i]->isRanged()) return true;
    return false;
}

bool Battle::performRangedAttack(bool fromX, std::string& message) {
    Army& attackers = fromX ? armyX_ : armyY_;
    Army& defenders = fromX ? armyY_ : armyX_;
    std::size_t& cursor = fromX ? rangedCursorX_ : rangedCursorY_;
    auto& units = attackers.units();

    while (cursor < units.size() && (!units[cursor] || !units[cursor]->isAlive() || !units[cursor]->isRanged()))
        ++cursor;
    if (cursor >= units.size()) return false;

    Unit* shooter = units[cursor].get();
    ++cursor;
    Unit* target = defenders.frontUnit();
    if (!target) return false;
    const int damage = shooter->rangedDamage();
    target->takeDamage(damage);
    std::ostringstream out;
    out << (fromX ? armyX_.name() : armyY_.name()) << ": " << shooter->name()
        << " стреляет по " << (fromX ? armyY_.name() : armyX_.name()) << ", наносит "
        << damage << " урона. У цели " << target->health() << '/' << target->maxHealth() << " HP.";
    if (!target->isAlive()) out << " Юнит погиб.";
    message = out.str();
    return true;
}

bool Battle::performMeleeAttack(bool fromX, std::string& message) {
    Army& attackers = fromX ? armyX_ : armyY_;
    Army& defenders = fromX ? armyY_ : armyX_;
    Unit* attacker = attackers.frontUnit();
    Unit* target = defenders.frontUnit();
    if (!attacker || !target) return false;

    const int damage = attacker->meleeDamage();
    target->takeDamage(damage);
    std::ostringstream out;
    out << (fromX ? armyX_.name() : armyY_.name()) << ": " << attacker->name()
        << " атакует в ближнем бою, наносит " << damage << " урона. У цели "
        << target->health() << '/' << target->maxHealth() << " HP.";
    if (attacker->isRanged()) out << " (Лучник вблизи наносит уменьшенный урон.)";
    if (!target->isAlive()) out << " Юнит погиб; следующий выйдет вперёд.";
    message = out.str();
    return true;
}

bool Battle::checkFinished(std::string& message) {
    const bool xAlive = armyX_.hasAliveUnits();
    const bool yAlive = armyY_.hasAliveUnits();
    if (!xAlive || !yAlive) {
        armyX_.removeDeadUnits();
        armyY_.removeDeadUnits();
        phase_ = BattlePhase::Finished;
        if (!xAlive && !yAlive) message = "Обе армии уничтожены. Ничья.";
        else if (xAlive) message = "Армия «" + armyX_.name() + "» победила!";
        else message = "Армия «" + armyY_.name() + "» победила!";
        return true;
    }
    return false;
}

StepResult Battle::step() {
    StepResult result;
    if (isFinished()) {
        result.message = resultText();
        result.finished = true;
        return result;
    }
    if (checkFinished(result.message)) {
        result.finished = true;
        return result;
    }

    switch (phase_) {
    case BattlePhase::MeleeX:
    case BattlePhase::MeleeY: {
        const bool fromX = phase_ == BattlePhase::MeleeX;
        const bool isFirstMelee = (firstArmy_ == 0 && fromX) || (firstArmy_ == 1 && !fromX);
        if (!performMeleeAttack(fromX, result.message)) {
            if (!checkFinished(result.message))
                result.message = fromX ? "Армия X пропускает атаку." : "Армия Y пропускает атаку.";
        }
        if (!isFinished()) {
            std::string finishMessage;
            if (checkFinished(finishMessage)) {
                if (!result.message.empty()) result.message += " ";
                result.message += finishMessage;
            } else if (isFirstMelee) {
                phase_ = fromX ? BattlePhase::MeleeY : BattlePhase::MeleeX;
            } else {
                phase_ = BattlePhase::Ranged;
                result.message += " Ближний бой завершён; начинается дальняя атака.";
            }
        }
        break;
    }
    case BattlePhase::Ranged: {
        const bool xHas = hasUnusedRangedUnit(armyX_, rangedCursorX_);
        const bool yHas = hasUnusedRangedUnit(armyY_, rangedCursorY_);
        if (!xHas && !yHas) {
            phase_ = BattlePhase::Cleanup;
            result.message = "Дальняя атака завершена. Погибшие будут удалены в конце раунда.";
            break;
        }

        bool chosenX = false;
        if (nextRangedArmy_ == 0 && xHas) chosenX = true;
        else if (nextRangedArmy_ == 1 && yHas) chosenX = false;
        else chosenX = xHas;
        nextRangedArmy_ = chosenX ? 1 : 0;
        if (!performRangedAttack(chosenX, result.message)) {
            result.message = "Стрелок не смог атаковать.";
        }
        {
            std::string finishMessage;
            if (checkFinished(finishMessage)) {
                if (!result.message.empty()) result.message += " ";
                result.message += finishMessage;
            }
        }
        break;
    }
    case BattlePhase::Cleanup: {
        const std::size_t removedX = armyX_.removeDeadUnits();
        const std::size_t removedY = armyY_.removeDeadUnits();
        ++round_;
        result.roundEnded = true;
        std::ostringstream out;
        out << "Раунд завершён. Удалено погибших юнитов: " << armyX_.name() << " — " << removedX
            << ", " << armyY_.name() << " — " << removedY << ".";
        if (checkFinished(result.message)) {
            out << " " << result.message;
            result.message = out.str();
        } else if (round_ > maxRounds_) {
            phase_ = BattlePhase::Finished;
            out << " Достигнут лимит раундов — ничья.";
            result.message = out.str();
        } else {
            phase_ = firstArmy_ == 0 ? BattlePhase::MeleeX : BattlePhase::MeleeY;
            rangedCursorX_ = 0;
            rangedCursorY_ = 0;
            nextRangedArmy_ = firstArmy_;
            result.message = out.str();
        }
        break;
    }
    case BattlePhase::Finished:
        result.message = resultText();
        break;
    }

    result.finished = isFinished();
    return result;
}

std::string Battle::phaseName(BattlePhase phase) {
    switch (phase) {
    case BattlePhase::Ranged: return "дальняя атака";
    case BattlePhase::MeleeX: return "ближний бой: ход армии X";
    case BattlePhase::MeleeY: return "ближний бой: ход армии Y";
    case BattlePhase::Cleanup: return "удаление погибших";
    case BattlePhase::Finished: return "бой завершён";
    }
    return "неизвестный этап";
}

std::string Battle::resultText() const {
    if (!isFinished()) return "Бой ещё продолжается.";
    const bool xAlive = armyX_.hasAliveUnits();
    const bool yAlive = armyY_.hasAliveUnits();
    if (!xAlive && !yAlive) return "Ничья: обе армии уничтожены или бой завершён без победителя.";
    if (xAlive && !yAlive) return "Победитель: «" + armyX_.name() + "».";
    if (yAlive && !xAlive) return "Победитель: «" + armyY_.name() + "».";
    return "Ничья: достигнут лимит раундов.";
}

void Battle::printState() const {
    auto printArmy = [](const Army& army) {
        std::cout << "\n" << army.name() << " | живых: " << army.aliveCount() << '/' << army.totalUnits()
                  << " | бюджет: " << army.remainingBudget() << '/' << army.initialBudget() << "\n";
        if (army.units().empty()) {
            std::cout << "  (нет юнитов)\n";
            return;
        }
        std::size_t index = 1;
        for (const auto& unit : army.units()) {
            std::cout << "  " << index++ << ". " << unit->name() << " — "
                      << unit->health() << '/' << unit->maxHealth() << " HP"
                      << (unit->isAlive() ? "" : " [погиб]") << "\n";
        }
        if (const Unit* front = army.frontUnit()) std::cout << "  Передний юнит: " << front->name() << "\n";
    };

    std::cout << "\n========================================\n"
              << "Раунд: " << round_ << " | Этап: " << phaseName(phase_) << "\n"
              << "Первой атакует: " << (firstArmy_ == 0 ? armyX_.name() : armyY_.name()) << "\n"
              << "========================================\n";
    printArmy(armyX_);
    printArmy(armyY_);
    if (isFinished()) std::cout << "\n" << resultText() << "\n";
}

namespace {
void writeArmy(std::ostream& out, const Army& army) {
    out << std::quoted(army.name()) << ' ' << army.initialBudget() << ' '
        << army.remainingBudget() << ' ' << army.units().size() << '\n';
    for (const auto& unit : army.units()) {
        out << std::quoted(unit->id()) << ' ' << unit->health() << '\n';
    }
}

Army readArmy(std::istream& in) {
    std::string name;
    int initialBudget = 0;
    int remainingBudget = 0;
    std::size_t count = 0;
    if (!(in >> std::quoted(name) >> initialBudget >> remainingBudget >> count))
        throw std::runtime_error("Не удалось прочитать параметры армии.");
    if (initialBudget < 0 || remainingBudget < 0 || remainingBudget > initialBudget || count > 100000)
        throw std::runtime_error("Некорректные параметры армии в файле сохранения.");

    Army army(name, initialBudget);
    for (std::size_t i = 0; i < count; ++i) {
        std::string typeId;
        int health = 0;
        if (!(in >> std::quoted(typeId) >> health))
            throw std::runtime_error("Не удалось прочитать юнита из сохранения.");
        auto unit = MilitaryAcademy::instance().createUnit(typeId);
        unit->setHealth(health);
        army.addLoadedUnit(std::move(unit));
    }
    army.setRemainingBudget(remainingBudget);
    return army;
}
} // namespace

bool SaveManager::save(const Battle& battle, const std::string& path, std::string& error) {
    std::ofstream out(path, std::ios::out | std::ios::trunc);
    if (!out) {
        error = "Не удалось открыть файл для записи: " + path;
        return false;
    }
    out << "BATTLE_GAME_SAVE 2\n";
    out << battle.round() << ' ' << static_cast<int>(battle.phase()) << ' '
        << battle.rangedCursorX() << ' ' << battle.rangedCursorY() << ' '
        << battle.nextRangedArmy() << ' ' << battle.firstArmy() << ' '
        << battle.maxRounds() << '\n';
    writeArmy(out, battle.armyX());
    writeArmy(out, battle.armyY());
    out.flush();
    if (!out) {
        error = "Ошибка во время записи сохранения.";
        return false;
    }
    error.clear();
    return true;
}

std::unique_ptr<Battle> SaveManager::load(const std::string& path, std::string& error) {
    try {
        std::ifstream in(path);
        if (!in) throw std::runtime_error("Не удалось открыть файл: " + path);
        std::string magic;
        int version = 0;
        if (!(in >> magic >> version) || magic != "BATTLE_GAME_SAVE" || (version != 1 && version != 2))
            throw std::runtime_error("Неверный формат или версия файла сохранения.");

        int round = 0;
        int phaseValue = 0;
        std::size_t cursorX = 0;
        std::size_t cursorY = 0;
        int nextArmy = 0;
        int firstArmy = 0;
        int maxRounds = 5000;
        if (version == 1) {
            if (!(in >> round >> phaseValue >> cursorX >> cursorY >> nextArmy >> maxRounds))
                throw std::runtime_error("Не удалось прочитать состояние боя.");
            // В версии 1 дальняя атака шла до ближнего боя. Переносим
            // сохранение в новый порядок фаз, не повторяя уже совершённые выстрелы.
            if (phaseValue == static_cast<int>(BattlePhase::Ranged))
                phaseValue = static_cast<int>(BattlePhase::MeleeX);
        } else {
            if (!(in >> round >> phaseValue >> cursorX >> cursorY >> nextArmy >> firstArmy >> maxRounds))
                throw std::runtime_error("Не удалось прочитать состояние боя.");
        }
        if (phaseValue < 0 || phaseValue > static_cast<int>(BattlePhase::Finished))
            throw std::runtime_error("В файле указана неизвестная фаза боя.");

        Army armyX = readArmy(in);
        Army armyY = readArmy(in);
        auto result = std::make_unique<Battle>(std::move(armyX), std::move(armyY), round,
            static_cast<BattlePhase>(phaseValue), cursorX, cursorY, nextArmy, firstArmy, maxRounds);
        error.clear();
        return result;
    } catch (const std::exception& ex) {
        error = ex.what();
        return nullptr;
    }
}

} // namespace battle_game
