#include "src/BattleGame.hpp"

#include <algorithm>
#include <chrono>
#include <cctype>
#include <iostream>
#include <limits>
#include <memory>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>

#ifdef _WIN32
#include <conio.h>
#include <windows.h>
#else
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>
#endif

using namespace battle_game;

namespace {

std::string trim(std::string value) {
    const auto first = std::find_if_not(value.begin(), value.end(),
        [](unsigned char ch) { return std::isspace(ch) != 0; });
    if (first == value.end()) return {};
    const auto last = std::find_if_not(value.rbegin(), value.rend(),
        [](unsigned char ch) { return std::isspace(ch) != 0; }).base();
    return std::string(first, last);
}

std::string readLine(const std::string& prompt) {
    std::cout << prompt;
    std::string value;
    if (!std::getline(std::cin, value)) throw std::runtime_error("Ввод завершён.");
    return trim(value);
}

int readInt(const std::string& prompt, int minValue, int maxValue) {
    while (true) {
        const std::string line = readLine(prompt);
        std::istringstream input(line);
        int value = 0;
        char extra = '\0';
        if ((input >> value) && !(input >> extra) && value >= minValue && value <= maxValue)
            return value;
        std::cout << "Введите целое число от " << minValue << " до " << maxValue << ".\n";
    }
}

std::string readOptionalName(const std::string& prompt, const std::string& defaultName) {
    std::string name = readLine(prompt + " (Enter — «" + defaultName + "»): ");
    return name.empty() ? defaultName : name;
}

void printCatalog() {
    const auto templates = MilitaryAcademy::instance().allTemplates();
    std::cout << "\nКаталог военной академии\n";
    std::cout << "---------------------------------------------------------------\n";
    std::cout << "№  Тип         Цена   HP    Урон ближний   Урон дальний   Дальность\n";
    std::cout << "---------------------------------------------------------------\n";
    for (std::size_t i = 0; i < templates.size(); ++i) {
        const Unit* unit = templates[i];
        std::cout << (i + 1) << ". " << unit->name()
                  << "\t" << unit->cost()
                  << "\t" << unit->maxHealth()
                  << "\t" << unit->meleeDamage()
                  << "\t\t" << unit->rangedDamage()
                  << "\t" << (unit->isRanged() ? "2-6, случайно" : "—") << "\n";
    }
    std::cout << "\nДальность каждого созданного лучника случайно выбирается от 2 до 6 условных клеток.\n";
    std::cout << "ID шаблонов (для разработчика): light, heavy, ranged\n";
    std::cout << "\nДобавление нового типа: зарегистрируйте prototype через MilitaryAcademy::instance().registerPrototype(...).\n\n";
}

std::unique_ptr<Army> createManualArmy(const std::string& name, int budget) {
    auto army = std::make_unique<Army>(name, budget);
    const auto templates = MilitaryAcademy::instance().allTemplates();

    while (true) {
        std::cout << "\nАрмия «" << army->name() << "»: остаток бюджета "
                  << army->remainingBudget() << " из " << army->initialBudget() << ".\n";
        for (std::size_t i = 0; i < templates.size(); ++i) {
            const Unit* unit = templates[i];
            std::cout << (i + 1) << ") " << unit->name() << " — цена " << unit->cost()
                      << ", HP " << unit->maxHealth() << ", ближний урон " << unit->meleeDamage()
                      << ", дальний урон " << unit->rangedDamage();
            if (unit->isRanged()) std::cout << ", дальность 2–6 (случайная для каждого лучника)";
            if (unit->cost() > army->remainingBudget()) std::cout << " [не хватает бюджета]";
            std::cout << "\n";
        }
        std::cout << "0) Закончить формирование армии\n";
        const int choice = readInt("Добавить юнита: ", 0, static_cast<int>(templates.size()));
        if (choice == 0) break;
        const Unit* selected = templates[static_cast<std::size_t>(choice - 1)];
        if (selected->cost() > army->remainingBudget()) {
            std::cout << "Не хватает денег на этого юнита. Выберите другого или завершите набор.\n";
            continue;
        }
        army->addUnit(MilitaryAcademy::instance().createUnit(selected->id()));
        std::cout << "Добавлен юнит: " << selected->name() << ".\n";
    }
    return army;
}

std::unique_ptr<Army> createArmyInteractive(const std::string& defaultName, int budget) {
    const std::string name = readOptionalName("Название армии", defaultName);
    std::cout << "Доступный бюджет армии «" << name << "»: " << budget << "\n";
    const int mode = readInt("Формирование армии: 1 — вручную, 2 — автоматически: ", 1, 2);
    if (mode == 1) return createManualArmy(name, budget);

    const int factoryChoice = readInt("Фабрика: 1 — жадная, 2 — случайная: ", 1, 2);
    std::unique_ptr<ArmyFactory> factory;
    if (factoryChoice == 1) factory = std::make_unique<GreedyArmyFactory>();
    else factory = std::make_unique<RandomArmyFactory>();

    auto army = factory->createArmy(name, budget);
    std::cout << "Фабрика создала армию «" << army->name() << "»: "
              << army->totalUnits() << " юнитов, потрачено "
              << (army->initialBudget() - army->remainingBudget())
              << ", остаток " << army->remainingBudget() << ".\n";
    return army;
}

std::unique_ptr<Battle> createBattleInteractive() {
    std::cout << "\n=== Создание боя ===\n";
    const int sharedBudget = readInt("Одинаковый стартовый бюджет для КАЖДОЙ армии: ", 0, 1000000000);
    std::cout << "Обе армии получат стартовый бюджет " << sharedBudget << ".\n";

    auto armyX = createArmyInteractive("Армия X", sharedBudget);
    auto armyY = createArmyInteractive("Армия Y", sharedBudget);

    std::cout << "\nКто атакует первым?\n"
              << "1) " << armyX->name() << "\n"
              << "2) " << armyY->name() << "\n"
              << "3) Случайный выбор\n";
    const int initiativeChoice = readInt("Ваш выбор: ", 1, 3);
    int firstArmy = initiativeChoice - 1;
    if (initiativeChoice == 3) {
        std::mt19937 engine{std::random_device{}()};
        std::uniform_int_distribution<int> chooseArmy(0, 1);
        firstArmy = chooseArmy(engine);
        std::cout << "Случайный выбор: первой атакует "
                  << (firstArmy == 0 ? armyX->name() : armyY->name()) << ".\n";
    }
    auto battle = std::make_unique<Battle>(std::move(*armyX), std::move(*armyY), firstArmy);
    std::cout << "\nАрмии сформированы с одинаковым бюджетом.\n"
              << "Первой атакует: " << (firstArmy == 0 ? battle->armyX().name() : battle->armyY().name()) << ".\n"
              << "Порядок каждого раунда: ближний бой по очереди, затем дальние атаки по очереди.\n";
    return battle;
}

#ifndef _WIN32
class RawTerminalMode {
public:
    RawTerminalMode() {
        if (isatty(STDIN_FILENO) == 0) return;
        if (tcgetattr(STDIN_FILENO, &old_) != 0) return;
        termios raw = old_;
        raw.c_lflag &= static_cast<tcflag_t>(~(ICANON | ECHO));
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 0;
        active_ = tcsetattr(STDIN_FILENO, TCSANOW, &raw) == 0;
    }
    ~RawTerminalMode() { restore(); }
    void restore() {
        if (active_) {
            tcsetattr(STDIN_FILENO, TCSANOW, &old_);
            active_ = false;
        }
    }
private:
    termios old_{};
    bool active_ = false;
};
#endif

bool pollKey(char& key) {
#ifdef _WIN32
    if (!_kbhit()) return false;
    key = static_cast<char>(_getch());
    return true;
#else
    fd_set set;
    FD_ZERO(&set);
    FD_SET(STDIN_FILENO, &set);
    timeval timeout{};
    timeout.tv_sec = 0;
    timeout.tv_usec = 0;
    if (select(STDIN_FILENO + 1, &set, nullptr, nullptr, &timeout) <= 0) return false;
    char value = '\0';
    if (read(STDIN_FILENO, &value, 1) != 1) return false;
    key = value;
    return true;
#endif
}

void automaticBattle(Battle& battle) {
    std::cout << "\nАвтобой запущен. Нажмите S — остановить и сохранить, P — приостановить, Q — вернуться в меню боя.\n";
    char command = '\0';
    {
#ifndef _WIN32
        RawTerminalMode rawMode;
#endif
        while (!battle.isFinished()) {
            const StepResult result = battle.step();
            std::cout << result.message << "\n";
            if (result.finished) break;

            char key = '\0';
            if (pollKey(key)) {
                key = static_cast<char>(std::tolower(static_cast<unsigned char>(key)));
                if (key == 's' || key == 'p' || key == 'q') {
                    command = key;
                    break;
                }
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(160));
        }
#ifndef _WIN32
        rawMode.restore();
#endif
    }

    if (command == 's') {
        std::string path = readLine("Файл сохранения (Enter — battle_save.txt): ");
        if (path.empty()) path = "battle_save.txt";
        std::string error;
        if (SaveManager::save(battle, path, error)) std::cout << "Игра сохранена в «" << path << "».\n";
        else std::cout << "Ошибка сохранения: " << error << "\n";
    } else if (command == 'p') {
        std::cout << "Автобой приостановлен. Текущее состояние сохранено в памяти; продолжите из меню боя.\n";
    }
    if (battle.isFinished()) std::cout << "\n" << battle.resultText() << "\n";
}

void battleMenu(Battle& battle) {
    while (true) {
        if (battle.isFinished()) {
            battle.printState();
            std::cout << "\n" << battle.resultText() << "\n";
            return;
        }

        std::cout << "\n=== Управление боем ===\n"
                  << "1) Сделать один шаг\n"
                  << "2) Автоматический бой\n"
                  << "3) Сохранить игру\n"
                  << "4) Показать состояние армий\n"
                  << "0) Выйти в главное меню (бой останется в памяти)\n";
        const int choice = readInt("Ваш выбор: ", 0, 4);
        if (choice == 0) return;
        if (choice == 1) {
            const StepResult result = battle.step();
            std::cout << result.message << "\n";
        } else if (choice == 2) {
            automaticBattle(battle);
        } else if (choice == 3) {
            std::string path = readLine("Файл сохранения (Enter — battle_save.txt): ");
            if (path.empty()) path = "battle_save.txt";
            std::string error;
            if (SaveManager::save(battle, path, error)) std::cout << "Игра сохранена в «" << path << "».\n";
            else std::cout << "Ошибка сохранения: " << error << "\n";
        } else if (choice == 4) {
            battle.printState();
        }
    }
}

} // namespace

int main() {
#ifdef _WIN32
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);
#endif
    try {
        // При первом обращении Singleton создаёт каталог шаблонов.
        (void)MilitaryAcademy::instance();
        std::unique_ptr<Battle> currentBattle;

        while (true) {
            std::cout << "\n========== BATTLE GAME =========="
                      << "\n1) Создать новую игру"
                      << "\n2) Продолжить текущую игру"
                      << "\n3) Загрузить сохранение"
                      << "\n4) Каталог военной академии"
                      << "\n0) Выход\n";
            const int choice = readInt("Ваш выбор: ", 0, 4);
            if (choice == 0) break;

            if (choice == 1) {
                currentBattle = createBattleInteractive();
                battleMenu(*currentBattle);
            } else if (choice == 2) {
                if (!currentBattle) {
                    std::cout << "Нет текущей игры. Создайте новую или загрузите сохранение.\n";
                } else {
                    battleMenu(*currentBattle);
                }
            } else if (choice == 3) {
                std::string path = readLine("Путь к файлу (Enter — battle_save.txt): ");
                if (path.empty()) path = "battle_save.txt";
                std::string error;
                auto loaded = SaveManager::load(path, error);
                if (!loaded) std::cout << "Не удалось загрузить игру: " << error << "\n";
                else {
                    currentBattle = std::move(loaded);
                    std::cout << "Сохранение загружено.\n";
                    battleMenu(*currentBattle);
                }
            } else if (choice == 4) {
                printCatalog();
            }
        }
        std::cout << "До свидания!\n";
    } catch (const std::exception& ex) {
        std::cerr << "Ошибка: " << ex.what() << "\n";
        return 1;
    }
    return 0;
}
